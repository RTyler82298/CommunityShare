package com.example.changingactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainPage extends AppCompatActivity {
    private Button Fool;
    private Button rides;
    private Button offers;

    public String UserId = "Dovid Duskis";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Fool = (Button) findViewById(R.id.You_Fool);
        Fool.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                showToast("Ha You Fool You Have Fallen For My Trap Card");
            }
        });

        rides = (Button) findViewById(R.id.Rides);
        rides.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                openRides();
            }
        });
        offers = findViewById(R.id.Offers);
        offers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                openOffers();
            }
        });
    }

    private void showToast(String text){
        Toast.makeText(MainPage.this, text, Toast.LENGTH_SHORT).show();
    }

    private void openRides() {
        Intent intent = new Intent(this,
                Rides.class);
        intent.putExtra("userId", UserId);
        startActivity(intent);
    }
    private void openOffers() {
        Intent intent = new Intent(this,
                Offers.class);
        intent.putExtra("userId", UserId);
        startActivity(intent);
    }
}