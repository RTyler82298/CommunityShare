package com.example.changingactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Search_Offer extends AppCompatActivity {
    String[] Qualities = {"New", "Good", "Normal", "Bad"};
    int number;
    String nameOfGood, item;
    Button posting;

    EditText numInput, nameInput;
    AutoCompleteTextView quality;

    ArrayAdapter<String> adapterItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_offer);

        numInput = findViewById(R.id.NumberOfItem2);
        nameInput = findViewById(R.id.NameOfItem2);

        quality = findViewById(R.id.Quality2);

        adapterItems = new ArrayAdapter<>(this, R.layout.list_items, Qualities);

        quality.setAdapter(adapterItems);

        quality.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                item = parent.getItemAtPosition(position).toString();
            }
        });

        posting = findViewById(R.id.OfferSearch);
        posting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                number = Integer.valueOf(numInput.getText().toString());
                nameOfGood = nameInput.getText().toString();
                showToast(nameOfGood + " " + number  + " " + item);
            }
        });
    }

    public void showToast(String text){
        Toast.makeText(Search_Offer.this, text, Toast.LENGTH_SHORT).show();
    }
}