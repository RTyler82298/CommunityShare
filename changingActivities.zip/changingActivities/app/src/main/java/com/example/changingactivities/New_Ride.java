package com.example.changingactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class New_Ride extends AppCompatActivity {
    String[] allowedGender = {"Mixed", "Male", "Female"};
    String date, time, leavingFrom, goingTo;
    String item = null;
    int passengers;

    Button submit;
    EditText dateInput, timeInput, leavingInput, goingInput, passengerInput;

    AutoCompleteTextView Gender_new;

    ArrayAdapter<String> adapterItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_ride);
        dateInput = findViewById(R.id.dayOf);
        timeInput = findViewById(R.id.timeOf);
        leavingInput = findViewById(R.id.LeavingFrom);
        goingInput = findViewById(R.id.GoingTo);
        passengerInput = findViewById(R.id.numOfPassengers);

        Gender_new = findViewById(R.id.autoGender);

        adapterItems = new ArrayAdapter<>(this, R.layout.list_items, allowedGender);

        Gender_new.setAdapter(adapterItems);

        Gender_new.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                item = parent.getItemAtPosition(position).toString();
                Toast.makeText(getApplicationContext(), "Item: "+item, Toast.LENGTH_SHORT).show();
            }
        });

        submit = findViewById(R.id.Post_Ride);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                date = dateInput.toString();
                time = timeInput.toString();
                leavingFrom = leavingInput.toString();
                goingTo = goingInput.toString();
                //passengers = Integer.valueOf(passengerInput.getText().toString());

                showToast(date + " " + time + " " + leavingFrom + " " + goingTo  + " " + item);
            }
        });
    }

    private void showToast(String text){
        Toast.makeText(New_Ride.this, text, Toast.LENGTH_SHORT).show();
    }
}