package com.example.changingactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Create_Community extends AppCompatActivity {
    Button button;
    EditText communityInput;
    String community;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_community);

        button = findViewById(R.id.button);
        communityInput = findViewById(R.id.NameOfCommunity);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                community = communityInput.getText().toString();
                showToast(community);

            }
        });
    }
    private void showToast(String text){
        Toast.makeText(Create_Community.this, text, Toast.LENGTH_SHORT).show();
    }
}