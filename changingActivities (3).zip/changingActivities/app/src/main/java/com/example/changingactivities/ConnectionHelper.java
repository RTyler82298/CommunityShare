package com.example.changingactivities;

import android.annotation.SuppressLint;
import android.os.StrictMode;
import android.util.Log;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionHelper {
    Connection con;
    String ip, port, db;

    @SuppressLint("NewApi")
    public Connection conclass(){
        ip="172.1.0.0;";
        port="1433";
        db="nameOf";

        StrictMode.ThreadPolicy pol = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(pol);
        Connection connection = null;
        String ConnectURL=null;
        try
        {
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
            ConnectURL="jdbc:jtds:sqlserver://"+ip+":"+port+"databaseName="+db+";user=;password=;";
            connection = DriverManager.getConnection(ConnectURL);
        }
        catch(Exception exc){
            Log.e("Error :", exc.getMessage());
        }
        return connection;
    }
}
