package com.example.changingactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Map;

// this is the login/create account page

public class MainActivity extends AppCompatActivity {
    private Button button;
    private Button button2;
    private String userName, password, email;


    EditText userInput, passwordInput;

    Map<String, String> ola;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        userInput = findViewById(R.id.User_Id);

        button = (Button) findViewById(R.id.log_in_button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                userName =  userInput.getText().toString();
                //password = passwordInput.getText().toString();

                openActivity2();
            }
        });

        button2 = findViewById(R.id.Create_Account_Button);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                openActivity();
            }
        });
    }

    private void openActivity() {
        Intent intent = new Intent(this, CreateAccount.class);
        startActivity(intent);
    }

    private void openActivity2(/*String s*/) {
        if(userName != null && !userName.equals("")) {
            Intent intent = new Intent(this, MainPage.class);
            String Community = "Hi";

            intent.putExtra("userName", userName);
            // it will check to see if the user is in a community
//          intent.putExtra("userEmail", email);
          intent.putExtra("Community", Community);
            // maybe we should save the community so we'll see intent.putExtra("userName", userName);

            startActivity(intent);
        }
    }
}