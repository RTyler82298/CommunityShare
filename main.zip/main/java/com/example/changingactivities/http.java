//package com.example.changingactivities;
//
//import java.io.BufferedInputStream;
//import java.io.IOException;
//import java.io.InputStream;
//import java.net.HttpURLConnection;
//import java.net.URL;
//
//public class http {
//
//    public void dur() throws IOException {
//
//
//    URL url = new URL("http://www.android.com/");
//    HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
//   try
//
//    {
//        InputStream in = new BufferedInputStream(urlConnection.getInputStream());
//        readStream(in);
//    } finally
//
//    {
//        urlConnection.disconnect();
//    }
//}
//}
