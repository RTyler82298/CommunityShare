package com.example.changingactivities;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import java.util.List;
import java.util.Map;

public class data_From_sql3 extends AppCompatActivity {
    List<Map<String,String>> myDataList = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_from_sql2);

    }

    SimpleAdapter ad;
    public void GetData3(View v){
        ListView listView = (ListView) findViewById(R.id.listview2);

        ListItem myData = new ListItem();
        myDataList = myData.getlist2();

        String[] Fromw = {"CommunityName"};
        int[] tow = {R.id.CommunityName};

        ad = new SimpleAdapter(this, myDataList,
                R.layout.community, Fromw, tow);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                showToast(myDataList.get(i).get("CommunityName"));
            }
        });
        listView.setAdapter(ad);
    }

    private void showToast(String text){
        Toast.makeText(this, text, Toast.LENGTH_SHORT).show();
    }
}