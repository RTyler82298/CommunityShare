package com.example.changingactivities;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ListItem {
    public List<Map<String, String>> getlist() {
        List<Map<String, String>> data = null;
        data = new ArrayList<Map<String, String>>();

        for (int i = 0; i < 50; i++) {
            Map<String, String> aa = new HashMap<String, String>();
            aa.put("Offered_by", "dave " + i);
            aa.put("NameOfGood", "hammer " + i);
            aa.put("Quality3", "good " + i);
            // aa.put("Col", "d"+i);
            aa.put("kol", "e" + i);
            data.add(aa);
        }
        return data;
    }

    public List<Map<String, String>> getlist2() {
        List<Map<String, String>> data = null;
        data = new ArrayList<Map<String, String>>();

        for (int i = 0; i < 50; i++) {
            Map<String, String> aa = new HashMap<String, String>();
            aa.put("Offered_by", "dave " + i);
            aa.put("GoingTo", "a " + i);
            aa.put("NameOfGood", "b " + i);
            aa.put("LeavingFrom", "c " + i);
            aa.put("LeavingDate", "d" + i);
            aa.put("LeavingTime", "e" + i);
            aa.put("numOfPassenger", "f" + i);
            data.add(aa);
        }
        return data;
    }

    public List<Map<String, String>> getlist3() {
        List<Map<String, String>> data = null;
        data = new ArrayList<Map<String, String>>();
        for (int i = 0; i < 50; i++) {
            Map<String, String> aa = new HashMap<String, String>();
            aa.put("CommunityName", "a" + i);
            data.add(aa);
        }
        return data;
    }
}
